/* עורך תמונות בגלריה: התאמות, חיתוך, סיבוב, יישור, סריקת מסמך */
const EDF={br:100,co:100,sa:100,wm:0,bw:0,rot:0,flip:0,ang:0,asp:0};let E,src,ed,Q=[],tab;
const btn=(t,f)=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;return b};
function edRender(s,E,max){let w=s.width,h=s.height;const k=Math.min(1,max/Math.max(w,h));w*=k;h*=k;const r=E.rot%2,W=r?h:w,H=r?w:h;let cw=W,ch=H;if(E.asp){if(W/H>E.asp)cw=H*E.asp;else ch=W/E.asp}
  const c=document.createElement('canvas');c.width=cw|0;c.height=ch|0;const x=c.getContext('2d'),a=Math.abs(E.ang)*Math.PI/180,z=Math.cos(a)+Math.sin(a)*Math.max(cw,ch)/Math.min(cw,ch);
  x.filter=`brightness(${E.br}%) contrast(${E.co}%) saturate(${E.sa}%) sepia(${E.wm}%)${E.bw?' grayscale(1)':''}`;x.translate(cw/2,ch/2);x.rotate((E.rot*90+E.ang)*Math.PI/180);if(E.flip)x.scale(-1,1);if(E.ang)x.scale(z,z);x.drawImage(s,-w/2,-h/2,w,h);return c}
const pv=()=>{const c=edRender(src,E,1100),o=$('#edc');o.width=c.width;o.height=c.height;o.getContext('2d').drawImage(c,0,0);if(tab=='doc')layoutQ()};
async function openEdit(it,doc){ed=it;src=await createImageBitmap(it.blob);E={...EDF};$('#ed').hidden=false;setTab(doc?'doc':'adj')}
function sl(n,k,a,b){const l=document.createElement('label');l.innerHTML=`<span>${n}</span><input type=range min=${a} max=${b} value=${E[k]}>`;l.lastChild.oninput=e=>{E[k]=+e.target.value;pv()};return l}
function setTab(t){tab=t;const p=$('#edp');p.innerHTML='';$('#edq').hidden=t!='doc';$$('#edt button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));
  if(t=='adj')p.append(sl('בהירות','br',50,150),sl('ניגודיות','co',50,160),sl('צבעוניות','sa',0,200),sl('חמימות','wm',0,60),btn('שחור לבן',()=>{E.bw=E.bw?0:1;pv()}),btn('אוטומטי',()=>{Object.assign(E,{co:112,sa:112,br:104});setTab('adj')}),btn('איפוס',()=>{E={...EDF};setTab('adj')}));
  if(t=='crop'){[['מקורי',0],['1:1',1],['4:3',4/3],['3:4',3/4],['16:9',16/9]].forEach(([n,a])=>p.append(btn(n,()=>{E.asp=a;pv()})));p.append(btn('סובב',()=>{E.rot=(E.rot+1)%4;pv()}),btn('הפוך',()=>{E.flip=E.flip?0:1;pv()}),sl('יישור','ang',-15,15))}
  if(t=='doc'){E={...EDF};Q=detect();const q=$('#edq');q.innerHTML='<svg><polygon/></svg>'+'<i></i>'.repeat(4);
    [...q.querySelectorAll('i')].forEach((h,i)=>{h.onpointerdown=e=>h.setPointerCapture(e.pointerId);h.onpointermove=e=>{if(!h.hasPointerCapture(e.pointerId))return;const r=$('#edc').getBoundingClientRect();Q[i]=[Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))];layoutQ()}});
    p.append(btn('זהה שוב',()=>{Q=detect();layoutQ()}),btn('החל סריקה',applyDoc))}
  pv()}
function layoutQ(){const r=$('#edc').getBoundingClientRect(),p=$('#edv').getBoundingClientRect(),h=[...$('#edq').querySelectorAll('i')],pt=Q.map(q=>[r.left-p.left+q[0]*r.width,r.top-p.top+q[1]*r.height]);
  h.forEach((e,i)=>{e.style.left=pt[i][0]+'px';e.style.top=pt[i][1]+'px'});$('#edq polygon').setAttribute('points',pt.map(x=>x.join(',')).join(' '))}
function detect(){const w=120,h=Math.round(120*src.height/src.width),c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(src,0,0,w,h);const d=x.getImageData(0,0,w,h).data,L=[];let m=0;
  for(let i=0;i<d.length;i+=4){const l=d[i]*.3+d[i+1]*.59+d[i+2]*.11;L.push(l);m+=l}m/=L.length;const t=[1e9,1e9,-1e9,-1e9],P=[[0,0],[w,0],[w,h],[0,h]];
  L.forEach((l,i)=>{if(l<m*1.05)return;const X=i%w,Y=i/w|0,s=X+Y,f=X-Y;if(s<t[0]){t[0]=s;P[0]=[X,Y]}if(f<t[1]){t[1]=f;P[3]=[X,Y]}if(s>t[2]){t[2]=s;P[2]=[X,Y]}if(f>t[3]){t[3]=f;P[1]=[X,Y]}});return P.map(p=>[p[0]/w,p[1]/h])}
function applyDoc(){const W=Math.min(2200,src.width),H=Math.round(src.height*W/src.width),c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(src,0,0,W,H);
  const s=x.getImageData(0,0,W,H).data,P=Q.map(p=>[p[0]*W,p[1]*H]),D=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]),ow=Math.round(Math.max(D(P[0],P[1]),D(P[3],P[2]))),oh=Math.round(Math.max(D(P[0],P[3]),D(P[1],P[2])));
  if(ow<50||oh<50)return;const o=x.createImageData(ow,oh),q=o.data;
  for(let j=0;j<oh;j++){const t=j/oh,lx=P[0][0]+(P[3][0]-P[0][0])*t,ly=P[0][1]+(P[3][1]-P[0][1])*t,rx=P[1][0]+(P[2][0]-P[1][0])*t,ry=P[1][1]+(P[2][1]-P[1][1])*t;
    for(let i=0;i<ow;i++){const u=i/ow,sx=Math.min(W-1,Math.max(0,(lx+(rx-lx)*u)|0)),sy=Math.min(H-1,Math.max(0,(ly+(ry-ly)*u)|0)),a=(sy*W+sx)*4,k=(j*ow+i)*4;q[k]=s[a];q[k+1]=s[a+1];q[k+2]=s[a+2];q[k+3]=255}}
  const r=document.createElement('canvas');r.width=ow;r.height=oh;r.getContext('2d').putImageData(o,0,0);src=r;E={...EDF,bw:1,co:155,br:112};setTab('adj')}
$$('#edt button').forEach(b=>b.onclick=()=>setTab(b.dataset.t));$('#edX').onclick=()=>$('#ed').hidden=true;
$('#edS').onclick=async()=>{const c=edRender(src,E,1e9),blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.95));await put({type:'image',blob,noGeo:true});$('#ed').hidden=true;toast('נשמר כעותק חדש ✓');if(!$('#gal').hidden)openGal()};
$('#vEdit').onclick=()=>{const it=G[gi];if(it&&it.type=='image')openEdit(it);else toast('עריכה זמינה לתמונות בלבד')};
