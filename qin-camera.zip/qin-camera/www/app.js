'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],sleep=t=>new Promise(r=>setTimeout(r,t));
const S=Object.assign({facing:'environment',mode:'photo',q:'smart',fmt:'image/jpeg',timer:0,burst:1,filter:'none',vres:1080,fps:30,grid:0},JSON.parse(localStorage.getItem('qinS')||'{}'));
const save=()=>localStorage.setItem('qinS',JSON.stringify(S));
const F={none:'none',cine:'contrast(1.15) saturate(.85) sepia(.15) hue-rotate(-8deg)',warm:'sepia(.25) saturate(1.2)',cool:'hue-rotate(12deg) saturate(.9)',bw:'grayscale(1) contrast(1.1)',vivid:'saturate(1.5) contrast(1.08)'};
const VR={720:[1280,720],1080:[1920,1080],2160:[3840,2160]};
const v=$('#v');let stream,track,caps={},zoom=1,dz=1,busy=false,torch=false,rec,chunks,aStream,paused=false,el=0,ana,lastQ='';
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),2200)}
const applyT=()=>{v.style.transform=`scale(${dz*(S.facing=='user'?-1:1)},${dz})`;v.style.filter=F[S.filter]};

/* ---------- מצלמה ---------- */
async function start(){
  if(stream)stream.getTracks().forEach(t=>t.stop());torch=false;$('#bFlash').classList.remove('on');
  const vid=V(S.mode)?{width:{ideal:VR[S.vres][0]},height:{ideal:VR[S.vres][1]},frameRate:{ideal:S.mode=='slow'?60:+S.fps}}:{width:{ideal:4096},height:{ideal:3072}};
  try{stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:S.facing,...vid},audio:false})}catch(e){return toast('אין גישה למצלמה — אשר הרשאה')}
  track=stream.getVideoTracks()[0];v.srcObject=stream;caps=track.getCapabilities?track.getCapabilities():{};
  const z=caps.zoom,r=$('#zoom');r.min=z?z.min:1;r.max=z?Math.min(z.max,20):8;r.step=.1;zoom=+r.min;dz=1;setZoom(zoom);buildPro();applyT();
}
async function setZoom(z){const r=$('#zoom');zoom=Math.max(+r.min,Math.min(+r.max,z));r.value=zoom;$('#zl').textContent=zoom.toFixed(1)+'×';
  if(caps.zoom){dz=1;try{await track.applyConstraints({advanced:[{zoom}]})}catch{}}else dz=zoom;applyT()}
$('#zoom').oninput=e=>setZoom(+e.target.value);

const PRO=[['exposureCompensation','חשיפה',{}],['iso','ISO',{exposureMode:'manual'}],['colorTemperature','איזון לבן',{whiteBalanceMode:'manual'}],['focusDistance','פוקוס',{focusMode:'manual'}]];
function buildPro(){const p=$('#pro');p.innerHTML='';
  PRO.forEach(([k,n,x])=>{const c=caps[k];if(!c||c.max===undefined)return;const l=document.createElement('label');
    l.innerHTML=`<span>${n}</span><input type=range min=${c.min} max=${c.max} step=${c.step||1} value=${(c.min+c.max)/2}>`;
    l.lastChild.oninput=e=>track.applyConstraints({advanced:[{[k]:+e.target.value,...x}]}).catch(()=>{});p.append(l)});
  if(!p.children.length)p.innerHTML='<span>המכשיר לא חושף שליטה ידנית לדפדפן</span>';
  else{const b=document.createElement('button');b.textContent='חזרה לאוטומטי';b.onclick=()=>{track.applyConstraints({advanced:[{whiteBalanceMode:'continuous',focusMode:'continuous',exposureMode:'continuous'}]}).catch(()=>{});buildPro()};p.append(b)}}

/* ---------- צילום מהיר ואיכותי ---------- */
const bmpOf=async()=>{try{return await new ImageCapture(track).grabFrame()}catch{const c=document.createElement('canvas');c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0);return c}};
const sc=document.createElement('canvas').getContext('2d',{willReadFrequently:true});
function sharp(b){const w=200,h=Math.round(200*b.height/b.width);sc.canvas.width=w;sc.canvas.height=h;sc.drawImage(b,0,0,w,h);
  const d=sc.getImageData(0,0,w,h).data,g=new Float32Array(w*h);for(let i=0;i<w*h;i++)g[i]=d[i*4]*.3+d[i*4+1]*.59+d[i*4+2]*.11;
  let s=0,s2=0,n=0;for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x,l=4*g[i]-g[i-1]-g[i+1]-g[i-w]-g[i+w];s+=l;s2+=l*l;n++}return s2/n-(s/n)**2}
function render(fr){const f=fr[0],w=f.width/dz,h=f.height/dz,c=document.createElement('canvas');c.width=w;c.height=h;
  const x=c.getContext('2d');x.filter=F[S.filter];fr.forEach((b,i)=>{x.globalAlpha=1/(i+1);x.drawImage(b,(f.width-w)/2,(f.height-h)/2,w,h,0,0,w,h)});return c}
async function shoot(q=S.q){
  if(busy)return;busy=true;const st=$('#stage');st.classList.add('fl');setTimeout(()=>st.classList.remove('fl'),90);
  try{let blob;
    if(q=='max'&&window.ImageCapture&&dz==1&&S.filter=='none'){try{const ic=new ImageCapture(track),pc=await ic.getPhotoCapabilities();blob=await ic.takePhoto(pc.imageWidth?{imageWidth:pc.imageWidth.max}:undefined)}catch{}}
    if(!blob){const n={fast:1,smart:3,max:3,night:6}[q],fr=[];
      for(let i=0;i<n;i++){fr.push(await bmpOf());if(i<n-1)await sleep(q=='night'?120:40)}
      let use=fr;if(q!='night'){const s=fr.map(sharp);use=[fr[s.indexOf(Math.max(...s))]]}
      blob=await new Promise(r=>render(use).toBlob(r,S.fmt,.97))}
    await put({type:'image',blob});toast('נשמר ✓')}
  catch(e){toast('הצילום נכשל')}finally{busy=false}}
async function countdown(n){const c=$('#cd');for(;n>0;n--){c.textContent=n;c.classList.add('on');await sleep(1000)}c.classList.remove('on')}
async function trigger(){if(S.mode=='video')return toggleRec();if(S.mode=='qr')return;if(S.timer)await countdown(S.timer);for(let i=0;i<S.burst;i++)await shoot(S.burst>1?'fast':S.q)}

/* ---------- וידאו ---------- */
async function toggleRec(){
  if(rec){rec.stop();return}
  try{aStream=await navigator.mediaDevices.getUserMedia({audio:{noiseSuppression:true}});
    const ac=new AudioContext();ana=ac.createAnalyser();ac.createMediaStreamSource(aStream).connect(ana)}catch{aStream=null;toast('מצלם ללא קול')}
  const mt=['video/mp4;codecs=avc1','video/webm;codecs=vp9,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t));
  rec=new MediaRecorder(new MediaStream([track,...(aStream?aStream.getAudioTracks():[])]),{mimeType:mt,videoBitsPerSecond:{720:8e6,1080:16e6,2160:5e7}[S.vres]});chunks=[];
  rec.ondataavailable=e=>e.data.size&&chunks.push(e.data);
  rec.onstop=async()=>{await put({type:'video',blob:new Blob(chunks,{type:mt.split(';')[0]})});if(aStream)aStream.getTracks().forEach(t=>t.stop());ana=null;rec=null;paused=false;
    $('#shut').classList.remove('rec');$('#rt').hidden=$('#snap').hidden=true;toast('הווידאו נשמר ✓')};
  rec.start(1000);el=0;paused=false;$('#shut').classList.add('rec');$('#rt').hidden=$('#snap').hidden=false;$('#pause').textContent='השהה'}
$('#pause').onclick=()=>{if(!rec)return;paused=!paused;paused?rec.pause():rec.resume();$('#pause').textContent=paused?'המשך':'השהה'};
$('#snap').onclick=()=>shoot('fast');
setInterval(()=>{if(!rec)return;if(!paused)el+=.25;const s=el|0;$('#rtt').textContent=String(s/60|0).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
  if(ana){const a=new Uint8Array(ana.fftSize);ana.getByteTimeDomainData(a);let m=0;a.forEach(x=>m=Math.max(m,Math.abs(x-128)));$('#mic u').style.width=Math.min(100,m*1.1)+'%'}},250);

/* ---------- היסטוגרמה, QR, פלס ---------- */
const hx=$('#hist').getContext('2d'),tm=document.createElement('canvas').getContext('2d',{willReadFrequently:true});tm.canvas.width=64;tm.canvas.height=48;
setInterval(()=>{if(!v.videoWidth)return;tm.drawImage(v,0,0,64,48);const d=tm.getImageData(0,0,64,48).data,h=new Array(32).fill(0);
  for(let i=0;i<d.length;i+=4)h[(d[i]*.3+d[i+1]*.59+d[i+2]*.11)>>3]++;const m=Math.max(...h);hx.clearRect(0,0,96,40);
  h.forEach((c,i)=>{hx.fillStyle=i>29?'#f55':'#fff';hx.fillRect(i*3,40-c/m*40,2,c/m*40)})},400);
setInterval(async()=>{if(S.mode!='qr'||!window.BarcodeDetector||!v.videoWidth)return;
  try{const r=await new BarcodeDetector({formats:['qr_code']}).detect(v);if(r[0]&&r[0].rawValue!==lastQ){lastQ=r[0].rawValue;$('#qr').hidden=false;$('#qr span').textContent=lastQ;$('#qo').hidden=!/^https?:/.test(lastQ)}}catch{}},400);
$('#qc').onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(lastQ);toast('הועתק')};$('#qo').onclick=()=>window.open(lastQ,'_blank');
addEventListener('deviceorientation',e=>{const g=e.gamma||0,l=$('#lvl');l.style.transform=`rotate(${-g}deg)`;l.classList.toggle('ok',Math.abs(g)<1.5)});

/* ---------- מחוות ---------- */
function gest(e0,o){const P=new Map,S0=new Map;let d0,s0,last=0;const dist=()=>{const [a,b]=[...P.values()];return Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY)};
  e0.addEventListener('pointerdown',e=>{if(o.skip&&o.skip(e))return;P.set(e.pointerId,e);S0.set(e.pointerId,e);e0.setPointerCapture(e.pointerId);if(P.size==2){d0=dist();s0=o.get()}});
  e0.addEventListener('pointermove',e=>{if(!P.has(e.pointerId))return;const p=P.get(e.pointerId);P.set(e.pointerId,e);
    if(P.size==2)o.set(s0*dist()/d0);else if(o.pan)o.pan(e.clientX-p.clientX,e.clientY-p.clientY)});
  e0.addEventListener('pointerup',e=>{if(!P.has(e.pointerId))return;const was=P.size,s=S0.get(e.pointerId);P.delete(e.pointerId);S0.delete(e.pointerId);
    if(was==1&&Math.hypot(e.clientX-s.clientX,e.clientY-s.clientY)<10){const n=Date.now();if(n-last<300&&o.dbl)o.dbl(e);else o.tap&&o.tap(e);last=n}});
  e0.addEventListener('pointercancel',e=>{P.delete(e.pointerId)})}
gest($('#stage'),{get:()=>zoom,set:setZoom,tap:e=>{if(e.target.closest('button,#pro,#qr'))return;const r=v.getBoundingClientRect(),g=$('#ring'),sr=$('#stage').getBoundingClientRect();
  g.style.left=e.clientX-sr.left+'px';g.style.top=e.clientY-sr.top+'px';g.classList.remove('on');void g.offsetWidth;g.classList.add('on');
  track.applyConstraints({advanced:[{pointsOfInterest:[{x:(e.clientX-r.left)/r.width,y:(e.clientY-r.top)/r.height}],focusMode:'single-shot'}]}).catch(()=>{})}});

/* ---------- אחסון וגלריה ---------- */
const db=new Promise(r=>{const q=indexedDB.open('qin',1);q.onupgradeneeded=()=>q.result.createObjectStore('m',{keyPath:'id',autoIncrement:true});q.onsuccess=()=>r(q.result)});
const tx=async(m,f)=>{const d=await db;return new Promise((res,rej)=>{const t=d.transaction('m',m),q=f(t.objectStore('m'));t.oncomplete=()=>res(q.result);t.onerror=rej})};
async function put(o){o.t=Date.now();if(o.type=='image'&&!o.noGeo&&window.geoTag)o.blob=await geoTag(o.blob);if(o.type=='image'){try{const b=await createImageBitmap(o.blob,{resizeWidth:320}),c=document.createElement('canvas');c.width=b.width;c.height=b.height;c.getContext('2d').drawImage(b,0,0);o.th=await new Promise(r=>c.toBlob(r,'image/jpeg',.8))}catch{}}
  o.id=await tx('readwrite',s=>s.add(o));lastThumb();if(window.saveGallery)saveGallery(o);return o}
async function lastThumb(){const c=await tx('readonly',s=>s.openCursor(null,'prev')),l=c&&c.value,t=$('#thumb');t.innerHTML=l?(l.type=='image'?'<img>':'▶'):'';if(l&&l.type=='image')t.firstChild.src=URL.createObjectURL(l.th||l.blob)}
let G=[],gi=0,urls=[],vz={s:1,x:0,y:0};
const ext=b=>({'image/jpeg':'jpg','image/webp':'webp','image/png':'png','video/mp4':'mp4','video/webm':'webm'}[b.type]||'bin'),nm=it=>`QIN_${new Date(it.t).toISOString().replace(/[:.]/g,'-')}.${ext(it.blob)}`;
async function openGal(){G=(await tx('readonly',s=>s.getAll())).reverse();$('#gal').hidden=false;const g=$('#gg');g.innerHTML='';
  G.forEach((it,i)=>{const d=document.createElement('div'),e=document.createElement(it.type=='image'?'img':'video'),u=URL.createObjectURL(it.th||it.blob);urls.push(u);e.src=it.type=='image'?u:u+'#t=0.1';if(it.type!='image'){e.muted=true;e.preload='metadata';d.innerHTML='<b>▶</b>'}
    d.prepend(e);d.onclick=()=>show(i);g.append(d)});if(!G.length)g.innerHTML='<p style="grid-column:1/-1;padding:40px;text-align:center;color:var(--mu)">אין עדיין תמונות. חזור וצלם.</p>'}
function closeGal(){$('#gal').hidden=true;urls.forEach(URL.revokeObjectURL);urls=[];lastThumb()}
const applyV=()=>{const e=$('#vbox').firstChild;if(e&&e.tagName=='IMG')e.style.transform=`translate(${vz.x}px,${vz.y}px) scale(${vz.s})`};
function show(i){if(!G.length)return;gi=(i+G.length)%G.length;const it=G[gi],b=$('#vbox'),u=URL.createObjectURL(it.blob);urls.push(u);vz={s:1,x:0,y:0};b.innerHTML='';
  const e=document.createElement(it.type=='image'?'img':'video');e.src=u;if(it.type!='image'){e.controls=true;e.playsInline=true}b.append(e);$('#vn').textContent=new Date(it.t).toLocaleString('he-IL');$('#vw').hidden=false}
gest($('#vbox'),{skip:e=>e.target.tagName=='VIDEO',get:()=>vz.s,set:s=>{vz.s=Math.max(1,Math.min(10,s));if(vz.s==1)vz.x=vz.y=0;applyV()},
  pan:(dx,dy)=>{if(vz.s>1){vz.x+=dx;vz.y+=dy;applyV()}},
  dbl:e=>{if(vz.s>1)vz={s:1,x:0,y:0};else vz={s:3,x:-(e.clientX-innerWidth/2)*2,y:-(e.clientY-innerHeight/2)*2};applyV()}});
$('#vPrev').onclick=()=>show(gi-1);$('#vNext').onclick=()=>show(gi+1);$('#vBack').onclick=()=>{$('#vw').hidden=true;$('#vbox').innerHTML=''};
const dl=()=>{const it=G[gi],a=document.createElement('a');a.href=URL.createObjectURL(it.blob);a.download=nm(it);a.click()};
$('#vDl').onclick=dl;
$('#vShare').onclick=()=>{const it=G[gi],f=new File([it.blob],nm(it),{type:it.blob.type});navigator.canShare&&navigator.canShare({files:[f]})?navigator.share({files:[f]}).catch(()=>{}):dl()};
$('#vDel').onclick=async()=>{if(!confirm('למחוק?'))return;await tx('readwrite',s=>s.delete(G[gi].id));G.splice(gi,1);if(G.length)show(gi);else{$('#vw').hidden=true;openGal()}};
$('#thumb').onclick=openGal;$('#gBack').onclick=closeGal;

/* ---------- ממשק והגדרות ---------- */
$('#shut').onclick=trigger;
$('#flip').onclick=()=>{if(rec)return;S.facing=S.facing=='user'?'environment':'user';save();start()};
$('#bFlash').onclick=async()=>{if(!caps.torch)return toast('אין פנס במצלמה הזו');torch=!torch;try{await track.applyConstraints({advanced:[{torch}]})}catch{}$('#bFlash').classList.toggle('on',torch)};
$('#bTimer').onclick=()=>{S.timer=[0,3,5,10][([0,3,5,10].indexOf(S.timer)+1)%4];save();ui()};
const GR=['','<svg viewBox="0 0 3 3" preserveAspectRatio="none"><path d="M1 0V3M2 0V3M0 1H3M0 2H3"/></svg>','<svg viewBox="0 0 1 1" preserveAspectRatio="none"><path d="M.382 0V1M.618 0V1M0 .382H1M0 .618H1"/></svg>','<svg viewBox="0 0 1 1" preserveAspectRatio="none"><path d="M0 0L1 1M1 0L0 1M.5 0L1 .5M0 .5L.5 1"/></svg>'];
$('#bGrid').onclick=()=>{S.grid=(S.grid+1)%4;save();ui()};
$('#bPro').onclick=()=>{$('#pro').hidden=!$('#pro').hidden;$('#bPro').classList.toggle('on',!$('#pro').hidden)};
$('#bSet').onclick=()=>$('#set').hidden=false;$('#sClose').onclick=()=>$('#set').hidden=true;
function ui(){$('#bTimer').textContent=S.timer?`טיימר ${S.timer}`:'טיימר';$('#bTimer').classList.toggle('on',!!S.timer);$('#grid').innerHTML=GR[S.grid];$('#lvl').classList.toggle('on',S.grid>0);$('#bGrid').classList.toggle('on',S.grid>0);
  $('#shut').className=S.mode+(rec?' rec':'');$$('#modes button').forEach(b=>b.classList.toggle('on',b.dataset.m==S.mode));if(S.mode!='qr')$('#qr').hidden=true;applyT()}
$$('#modes button').forEach(b=>b.onclick=()=>{if(rec)return;const old=S.mode;S.mode=b.dataset.m;save();ui();if((old=='video')!=(S.mode=='video'))start()});
$$('[data-k]').forEach(e=>{e.value=S[e.dataset.k];e.onchange=()=>{S[e.dataset.k]=isNaN(e.value)?e.value:+e.value;save();applyT();if(['vres','fps'].includes(e.dataset.k)&&S.mode=='video')start()}});
addEventListener('keydown',e=>{if($('#gal').hidden&&[24,25].includes(e.keyCode)||['AudioVolumeUp','AudioVolumeDown','VolumeUp','VolumeDown'].includes(e.key)){e.preventDefault();trigger()}});
ui();lastThumb();if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
