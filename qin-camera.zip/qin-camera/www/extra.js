/* מצבים נוספים: HDR, פורטרט, פנורמה, מסמך, Time-lapse, האטה, ייצוב, Zebra, זיהוי פנים/חיוך, GPS/EXIF, שמירה לגלריה */
const V=m=>['video','slow','tl'].includes(m),SG=1; /* אם הייצוב זז לכיוון הלא נכון החלף ל-1- */
Object.assign(S,{geo:0,zebra:0,stab:0,tl:2,auto:0,...JSON.parse(localStorage.getItem('qinS')||'{}')});
const N=()=>window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.QinNative,VMT=()=>['video/mp4;codecs=avc1','video/webm;codecs=vp9,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t));
const b64=b=>new Promise(r=>{const f=new FileReader;f.onload=()=>r(f.result.split(',')[1]);f.readAsDataURL(b)});

/* שמירה לגלריית הטלפון (MediaStore דרך הפלאגין הנייטיבי) */
async function saveGallery(o){const n=N();if(!n)return;try{const {id}=await n.begin({name:nm(o),mime:o.blob.type});
  for(let i=0;i<o.blob.size;i+=1<<20)await n.write({id,data:await b64(o.blob.slice(i,i+(1<<20)))});await n.finish({id});toast('נשמר בגלריה ✓')}catch(e){toast('שמירה לגלריה נכשלה')}}

/* GPS + EXIF */
let pos=null,gw=null;
function geoOn(){if(S.geo&&!gw&&navigator.geolocation)gw=navigator.geolocation.watchPosition(p=>pos=p.coords,()=>{},{enableHighAccuracy:true,maximumAge:30000});else if(!S.geo&&gw){navigator.geolocation.clearWatch(gw);gw=null;pos=null}}
function exifSeg(lat,lon){const b=new DataView(new ArrayBuffer(128));let p=0;const w2=v=>{b.setUint16(p,v);p+=2},w4=v=>{b.setUint32(p,v);p+=4};
  w2(0x4d4d);w2(42);w4(8);w2(1);w2(0x8825);w2(4);w4(1);w4(26);w4(0);
  const ref=(t,c)=>{w2(t);w2(2);w4(2);b.setUint8(p,c.charCodeAt(0));p+=4},rat=(t,o)=>{w2(t);w2(5);w4(3);w4(o)};
  w2(4);ref(1,lat<0?'S':'N');rat(2,80);ref(3,lon<0?'W':'E');rat(4,104);w4(0);
  const dms=x=>{x=Math.abs(x);const d=x|0,m=((x-d)*60)|0;return[d,1,m,1,Math.round(((x-d)*60-m)*6000),100]};
  [...dms(lat),...dms(lon)].forEach(w4);return[new Uint8Array([255,225,0,136,69,120,105,102,0,0]),new Uint8Array(b.buffer)]}
async function geoTag(bl){if(!pos||bl.type!='image/jpeg')return bl;const u=new Uint8Array(await bl.arrayBuffer());if(u[0]!=255||u[1]!=216)return bl;return new Blob([u.slice(0,2),...exifSeg(pos.latitude,pos.longitude),u.slice(2)],{type:'image/jpeg'})}

/* זיהוי פנים וחיוך (ML Kit נייטיבי, אחרת FaceDetector של הדפדפן) */
const fc=document.createElement('canvas');fc.width=240;
async function faces(){if(!v.videoWidth)return[];fc.height=Math.round(240*v.videoHeight/v.videoWidth);fc.getContext('2d').drawImage(v,0,0,fc.width,fc.height);const n=N();
  if(n)try{return(await n.faces({data:fc.toDataURL('image/jpeg',.6).split(',')[1]})).faces}catch{}
  if(window.FaceDetector)try{return(await new FaceDetector({fastMode:true}).detect(fc)).map(f=>{const b=f.boundingBox;return{x:(b.x+b.width/2)/fc.width,y:(b.y+b.height/2)/fc.height,w:b.width/fc.width,smile:0}})}catch{}return[]}
let aN=0,aT=0;setInterval(async()=>{if(!S.auto||busy||rec||tl||pano||V(S.mode)||S.mode=='qr'||Date.now()-aT<4000)return;const f=await faces(),ok=S.auto==2?f.some(x=>x.smile>.8):f.length>0;aN=ok?aN+1:0;
  if(aN>=(S.auto==2?1:3)){aN=0;aT=Date.now();shoot(S.q)}},400);

/* HDR: 3 חשיבות ומיזוג לפי איזון חשיפה */
async function hdr(){const ec=caps.exposureCompensation,fr=[];
  for(const e of ec?[ec.min*.6,0,ec.max*.6]:[0,0,0]){if(ec){await track.applyConstraints({advanced:[{exposureCompensation:e}]}).catch(()=>{});await sleep(170)}fr.push(await bmpOf())}
  if(ec)track.applyConstraints({advanced:[{exposureCompensation:0}]}).catch(()=>{});
  const W=Math.min(2560,fr[0].width),H=Math.round(W*fr[0].height/fr[0].width),c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d',{willReadFrequently:true});
  const D=fr.map(f=>{x.drawImage(f,0,0,W,H);return x.getImageData(0,0,W,H).data}),o=x.createImageData(W,H),q=o.data;
  for(let i=0;i<q.length;i+=4){let s=0,r=0,g=0,b=0;for(const a of D){const l=a[i]*.3+a[i+1]*.59+a[i+2]*.11,w=Math.exp(-((l-128)**2)/7200)+1e-4;s+=w;r+=a[i]*w;g+=a[i+1]*w;b+=a[i+2]*w}q[i]=r/s;q[i+1]=g/s;q[i+2]=b/s;q[i+3]=255}
  x.putImageData(o,0,0);return c}

/* פורטרט: טשטוש רקע סביב הפנים */
async function bokeh(c0){const k=Math.min(1,2400/c0.width),c=document.createElement('canvas');c.width=c0.width*k;c.height=c0.height*k;c.getContext('2d').drawImage(c0,0,0,c.width,c.height);
  const f=(await faces()).sort((a,b)=>b.w-a.w)[0]||{x:.5,y:.42,w:.3},W=c.width,H=c.height,o=document.createElement('canvas');o.width=W;o.height=H;const x=o.getContext('2d');
  x.filter=`blur(${W/90}px)`;x.drawImage(c,0,0);x.filter='none';const m=document.createElement('canvas');m.width=W;m.height=H;const y=m.getContext('2d');y.drawImage(c,0,0);y.globalCompositeOperation='destination-in';
  const g=y.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,'#000');g.addColorStop(.65,'#000');g.addColorStop(1,'#0000');
  y.translate(f.x*W,f.y*H+f.w*W*.9);y.scale(f.w*W*1.7,f.w*W*3.2);y.fillStyle=g;y.fillRect(-1,-1,2,2);x.drawImage(m,0,0);return o}

const _shoot=shoot;
shoot=async function(q=S.q){const m=S.mode,k=(m=='portrait'||m=='doc')?m:q=='hdr'?'hdr':0;if(!k)return _shoot(q);if(busy)return;busy=true;const st=$('#stage');st.classList.add('fl');setTimeout(()=>st.classList.remove('fl'),90);
  try{let c;if(k=='hdr')c=render([await hdr()]);else{const fr=[];for(let i=0;i<3;i++){fr.push(await bmpOf());await sleep(40)}const s=fr.map(sharp);c=render([fr[s.indexOf(Math.max(...s))]]);if(k=='portrait')c=await bokeh(c)}
    const it=await put({type:'image',blob:await new Promise(r=>c.toBlob(r,S.fmt,.97))});toast('נשמר ✓');if(k=='doc')openEdit(it,true)}catch(e){toast('הצילום נכשל')}finally{busy=false}};

/* פנורמה: חיתוכי רצועות לפי זווית הסיבוב מהחיישן */
let pano=null;
async function panoToggle(){if(pano){removeEventListener('deviceorientation',pano.h);const p=pano;pano=null;$('#shut').classList.remove('rec');return panoDone(p)}
  const f=await bmpOf(),sc=Math.min(1,1600/f.height),p=pano={th:0,last:-99,prev:null,S:[],sc,ppd:f.width*sc/55,busy:false};
  p.h=async e=>{if(e.alpha==null)return;if(p.prev!=null){let d=e.alpha-p.prev;if(d>180)d-=360;if(d<-180)d+=360;p.th-=d}p.prev=e.alpha;
    if(!p.busy&&Math.abs(p.th-p.last)>=3){p.busy=true;p.last=p.th;const th=p.th,fr=await bmpOf(),sw=fr.width*3.6/55,c=document.createElement('canvas');c.width=Math.ceil(sw*p.sc);c.height=Math.round(fr.height*p.sc);
      c.getContext('2d').drawImage(fr,(fr.width-sw)/2,0,sw,fr.height,0,0,c.width,c.height);p.S.push([th*p.ppd-c.width/2,c]);toast('פנורמה '+Math.round(Math.abs(th))+'°');p.busy=false;if(Math.abs(th)>=250)trigger()}};
  addEventListener('deviceorientation',p.h);$('#shut').classList.add('rec');toast('הזז לאט הצידה, לחץ שוב לסיום')}
async function panoDone(p){if(p.S.length<2)return toast('הזז את הטלפון יותר');const mn=Math.min(...p.S.map(s=>s[0])),mx=Math.max(...p.S.map(s=>s[0]+s[1].width)),c=document.createElement('canvas');c.width=mx-mn|0;c.height=p.S[0][1].height;const x=c.getContext('2d');
  p.S.forEach(([px,s])=>x.drawImage(s,px-mn,0));await put({type:'image',blob:await new Promise(r=>render([c]).toBlob(r,S.fmt,.95))});toast('הפנורמה נשמרה ✓')}

/* קידוד וידאו מקנבס (Time-lapse / האטה / ייצוב) */
async function canvasRec(w,h,fps,run){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d'),mt=VMT(),r=new MediaRecorder(c.captureStream(fps),{mimeType:mt,videoBitsPerSecond:14e6}),ch=[];
  r.ondataavailable=e=>e.data.size&&ch.push(e.data);const done=new Promise(s=>r.onstop=s);r.start(500);await run(x,c);r.stop();await done;return new Blob(ch,{type:mt.split(';')[0]})}
let tl=null;
async function tlToggle(){if(tl){clearInterval(tl.i);const f=tl.f;tl=null;$('#shut').classList.remove('rec');$('#rt').hidden=true;$('#pause').hidden=false;toast('מקודד...');
    const b0=await createImageBitmap(f[0]);return put({type:'video',blob:await canvasRec(b0.width,b0.height,30,async x=>{for(const fb of f){x.drawImage(await createImageBitmap(fb),0,0);await sleep(34)}})}).then(()=>toast('Time-lapse נשמר ✓'))}
  tl={f:[]};$('#shut').classList.add('rec');$('#rt').hidden=false;$('#pause').hidden=true;
  const cap=async()=>{const c=document.createElement('canvas');c.width=1280;c.height=Math.round(1280*v.videoHeight/v.videoWidth);c.getContext('2d').drawImage(v,0,0,c.width,c.height);tl.f.push(await new Promise(r=>c.toBlob(r,'image/jpeg',.85)));$('#rtt').textContent=tl.f.length+' פריימים'};cap();tl.i=setInterval(cap,S.tl*1000)}
const slowEnc=async b=>{const vv=document.createElement('video');vv.muted=true;vv.src=URL.createObjectURL(b);await new Promise(r=>vv.onloadedmetadata=r);vv.playbackRate=.5;
  return canvasRec(vv.videoWidth,vv.videoHeight,30,async x=>{await vv.play();await new Promise(r=>{const d=()=>{x.drawImage(vv,0,0);vv.ended?r():requestAnimationFrame(d)};vv.onended=r;d()})})};

/* הקלטה: מסלול קנבס כשיש זום דיגיטלי / פילטר / ייצוב */
toggleRec=async function(){if(S.mode=='tl')return tlToggle();if(rec){rec.stop();return}
  try{aStream=await navigator.mediaDevices.getUserMedia({audio:{noiseSuppression:true}});const ac=new AudioContext();ana=ac.createAnalyser();ac.createMediaStreamSource(aStream).connect(ana)}catch{aStream=null;toast('מצלם ללא קול')}
  let vt=track,stop=()=>{};
  if(dz>1||S.stab||S.filter!='none'){const w=v.videoWidth,h=v.videoHeight,c=document.createElement('canvas'),x=c.getContext('2d');c.width=w;c.height=h;let run=true,ox=0,oy=0;
    const mh=e=>{const r=e.rotationRate;if(!r||!S.stab)return;const k=w/.96*.016*Math.PI/180*SG,m=w*.05;ox=Math.max(-m,Math.min(m,(ox-r.gamma*k)*.96));oy=Math.max(-m,Math.min(m,(oy-r.beta*k)*.96))};addEventListener('devicemotion',mh);
    const lp=()=>{if(!run)return;const z=dz*(S.stab?1.12:1);x.filter=F[S.filter];x.save();x.translate(w/2+ox,h/2+oy);x.scale(z,z);x.drawImage(v,-w/2,-h/2,w,h);x.restore();requestAnimationFrame(lp)};lp();
    vt=c.captureStream(S.mode=='slow'?60:+S.fps).getVideoTracks()[0];stop=()=>{run=false;removeEventListener('devicemotion',mh)}}
  const mt=VMT();rec=new MediaRecorder(new MediaStream([vt,...(aStream?aStream.getAudioTracks():[])]),{mimeType:mt,videoBitsPerSecond:{720:8e6,1080:16e6,2160:5e7}[S.vres]});chunks=[];rec.ondataavailable=e=>e.data.size&&chunks.push(e.data);
  rec.onstop=async()=>{stop();let b=new Blob(chunks,{type:mt.split(';')[0]});if(aStream)aStream.getTracks().forEach(t=>t.stop());ana=null;rec=null;paused=false;$('#shut').classList.remove('rec');$('#rt').hidden=$('#snap').hidden=true;
    if(S.mode=='slow'){toast('מייצר האטה...');b=await slowEnc(b)}await put({type:'video',blob:b});toast('הווידאו נשמר ✓')};
  rec.start(1000);el=0;paused=false;$('#shut').classList.add('rec');$('#rt').hidden=$('#snap').hidden=false;$('#pause').textContent='השהה'};
trigger=async function(){const m=S.mode;if(V(m))return toggleRec();if(m=='qr')return;if(m=='pano')return panoToggle();if(S.timer)await countdown(S.timer);for(let i=0;i<S.burst;i++)await shoot(S.burst>1?'fast':S.q)};

/* Zebra */
const zc=$('#zb'),zx=zc.getContext('2d');zc.width=64;zc.height=48;
setInterval(()=>{if(!S.zebra||!v.videoWidth){zc.style.display='none';return}zc.style.display='block';zx.drawImage(v,0,0,64,48);const im=zx.getImageData(0,0,64,48),d=im.data;
  for(let i=0;i<d.length;i+=4){const p=i/4,hot=d[i]*.3+d[i+1]*.59+d[i+2]*.11>242&&((p%64+(p/64|0))%4<2);d[i]=255;d[i+1]=d[i+2]=0;d[i+3]=hot?190:0}zx.putImageData(im,0,0)},300);

/* חיבורים */
$('#shut').onclick=()=>trigger();addEventListener('volumeKey',()=>{if($('#gal').hidden&&$('#ed').hidden)trigger()});
$$('#modes button').forEach(b=>b.onclick=()=>{if(rec||tl||pano)return;const o=S.mode;S.mode=b.dataset.m;save();ui();if(V(o)!=V(S.mode)||S.mode=='slow'||o=='slow')start()});
$$('[data-k]').forEach(e=>e.value=S[e.dataset.k]);$('[data-k=geo]').addEventListener('change',geoOn);geoOn();ui();start();
