package com.qin.camera;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** שמירה לגלריה (MediaStore, DCIM/QinCamera) + זיהוי פנים/חיוך (ML Kit). */
@CapacitorPlugin(name = "QinNative")
public class QinNativePlugin extends Plugin {
    private final Map<String, Object[]> open = new HashMap<>();
    private FaceDetector fd;

    @PluginMethod
    public void begin(PluginCall c) {
        try {
            String mime = c.getString("mime");
            boolean vid = mime.startsWith("video");
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, c.getString("name"));
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/QinCamera");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            }
            Uri base = vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            Uri u = getContext().getContentResolver().insert(base, v);
            OutputStream os = getContext().getContentResolver().openOutputStream(u);
            String id = UUID.randomUUID().toString();
            open.put(id, new Object[]{os, u});
            JSObject r = new JSObject();
            r.put("id", id);
            c.resolve(r);
        } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void write(PluginCall c) {
        try {
            ((OutputStream) open.get(c.getString("id"))[0]).write(Base64.decode(c.getString("data"), Base64.DEFAULT));
            c.resolve();
        } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void finish(PluginCall c) {
        try {
            Object[] o = open.remove(c.getString("id"));
            ((OutputStream) o[0]).close();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContext().getContentResolver().update((Uri) o[1], v, null, null);
            }
            c.resolve();
        } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void faces(PluginCall c) {
        try {
            if (fd == null) fd = FaceDetection.getClient(new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build());
            byte[] b = Base64.decode(c.getString("data"), Base64.DEFAULT);
            final Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length);
            fd.process(InputImage.fromBitmap(bm, 0)).addOnSuccessListener(list -> {
                JSArray a = new JSArray();
                for (Face f : list) {
                    Rect r = f.getBoundingBox();
                    JSObject o = new JSObject();
                    o.put("x", (r.left + r.width() / 2.0) / bm.getWidth());
                    o.put("y", (r.top + r.height() / 2.0) / bm.getHeight());
                    o.put("w", (double) r.width() / bm.getWidth());
                    Float s = f.getSmilingProbability();
                    o.put("smile", s == null ? 0.0 : (double) s);
                    a.put(o);
                }
                JSObject res = new JSObject();
                res.put("faces", a);
                c.resolve(res);
            }).addOnFailureListener(e -> c.reject(String.valueOf(e.getMessage())));
        } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
    }
}
