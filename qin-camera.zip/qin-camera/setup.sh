#!/usr/bin/env bash
# מריצים פעם אחת מתוך התיקייה: bash setup.sh   (דרוש Node.js; לבנייה Android Studio)
set -e
npm install
[ -d android ] || npx cap add android
D=android/app/src/main/java/com/qin/camera
mkdir -p "$D" && cp native/*.java "$D/"
python3 - <<'PY'
m='android/app/src/main/AndroidManifest.xml'; s=open(m).read()
perm='''<uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-feature android:name="android.hardware.camera" android:required="false"/>
    '''
if 'RECORD_AUDIO' not in s: open(m,'w').write(s.replace('<application',perm+'<application',1))
g='android/app/build.gradle'; t=open(g).read()
if 'mlkit' not in t: open(g,'w').write(t.replace('dependencies {',"dependencies {\n    implementation 'com.google.mlkit:face-detection:16.1.6'",1))
PY
npx cap sync android
echo "מוכן. לבניית APK: npx cap open android  ->  Build > Build APK(s)"
